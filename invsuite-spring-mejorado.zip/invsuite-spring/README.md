# InvSuite Spring — Sistema de Inventario y Notificaciones
**TechFin Perú S.A.C. — Informe 2 del Proyecto (Curso Integrador I: Sistemas - Software, 1SI53)**

Aplicación web que centraliza y automatiza la gestión de inventario: productos,
categorías, proveedores, clientes, entradas, salidas, notificaciones automáticas
por stock mínimo, información de la empresa y reportes exportables a PDF.

Esta es la **Alternativa 2 (seleccionada)** de las tres alternativas planteadas en
el Informe 1. Backend 100 % Java (Spring Boot); la vista es Thymeleaf + Bootstrap
(HTML/CSS, no cuenta como lenguaje de programación), por lo que se cumple
ampliamente el requisito de la rúbrica de un mínimo de 50 % Java.

---

## 1. Tecnologías

| Capa | Tecnología |
|---|---|
| Lenguaje / backend | Java 17 — Spring Boot 3.3.2 (Web, Data JPA, Security, Validation) |
| Vista | Thymeleaf + Bootstrap 5 (plantillas HTML) |
| Persistencia | Spring Data JPA / Hibernate sobre MySQL 8 (JDBC) |
| Seguridad | Spring Security — BCrypt y control de acceso por roles |
| Reportes PDF | openhtmltopdf |
| Build | Maven (incluye wrapper `mvnw`) |

## 2. Módulos (cobertura del 100 % del alcance)

| Módulo | RF cubierto |
|---|---|
| Login / autenticación | RF-01, RF-11 |
| Usuarios y roles (ADMIN, INVENTARIO, VENTAS, GERENTE) | RF-11 |
| Categorías | RF-02 |
| Proveedores | RF-03 |
| Clientes | RF-04 |
| Productos (stock mínimo, precio) | RF-05 |
| Entradas de inventario | RF-06 |
| Salidas de inventario (valida disponibilidad) | RF-07 |
| Notificaciones automáticas por stock mínimo | RF-08 |
| Información de la empresa | RF-10 |
| Reportes (inventario y movimientos, PDF) | RF-09 |

## 3. Arquitectura (MVC por capas)

```
controller/   Controladores Spring MVC (GET/POST)
service/      Reglas de negocio (stock, notificaciones, reportes)
repository/   Spring Data JPA (acceso a datos)
model/        Entidades JPA (Producto, Entrada, Salida, ...)
config/       SecurityConfig (BCrypt + roles) y DataSeeder
templates/    Vistas Thymeleaf por módulo
```

## 4. Requisitos previos

1. JDK 17 o superior.
2. MySQL 8 corriendo en `localhost:3306` (XAMPP es suficiente).
3. Maven, o usar el wrapper incluido (`mvnw` / `mvnw.cmd`).

## 5. Configuración de la base de datos

Valores por defecto en `src/main/resources/application.properties`:

```
jdbc:mysql://localhost:3306/invsuite_techfin
usuario: root
contraseña: (vacía, como en XAMPP por defecto)
```

La base de datos y las tablas se crean automáticamente al iniciar
(`createDatabaseIfNotExist=true` + `spring.jpa.hibernate.ddl-auto=update`).
Si tu MySQL usa otra credencial, edítala en `application.properties`.

## 6. Ejecutar el proyecto

```bash
cd invsuite-spring
./mvnw spring-boot:run        # Linux/Mac
mvnw.cmd spring-boot:run      # Windows
```

(o `mvn spring-boot:run` si Maven está instalado globalmente).

Aplicación disponible en: **http://localhost:8080**

## 7. Usuario inicial

`DataSeeder` crea automáticamente al arrancar por primera vez:

- Roles: `ADMIN`, `INVENTARIO`, `VENTAS`, `GERENTE`
- Usuario administrador:
  - **Correo:** `admin@techfin.pe`
  - **Contraseña:** `admin123`
- Registro base de la empresa (TechFin Perú S.A.C.)

> Las contraseñas se cifran con BCrypt en tiempo de ejecución (RNF-03);
> no se almacenan en texto plano en ningún archivo del proyecto.

## 8. Prueba rápida del flujo completo

1. Iniciar sesión con `admin@techfin.pe / admin123`.
2. Crear una categoría y un proveedor.
3. Registrar un producto con **stock mínimo** mayor que 0.
4. Registrar una **entrada** y luego una **salida** que deje el stock
   por debajo del mínimo → el sistema genera la notificación (RF-08).
5. Revisar el panel principal y el módulo **Reportes** para exportar el
   reporte de stock en PDF (RF-09).

## 9. Seguridad y roles

| Ruta | Rol requerido |
|---|---|
| `/usuarios/**`, `/empresa/**` | ADMIN |
| `/productos/**`, `/categorias/**`, `/proveedores/**` | ADMIN, INVENTARIO |
| `/movimientos/**` (entradas/salidas) | ADMIN, INVENTARIO, VENTAS |
| `/reportes/**`, `/notificaciones/**` | Todos los roles autenticados |

---

**Universidad Tecnológica del Perú — Ingeniería de Sistemas — 2026**
Integrantes: Miqueas Lancho Ramos · Wilson Daniel Lázaro Rodríguez · Orlando Miguel Malpartida Janampa
Docente: Irani Guillén Gómez
