package com.techfin.invsuite.controller;

import com.techfin.invsuite.model.Proveedor;
import com.techfin.invsuite.service.ProveedorService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

/** RF-03: registrar, modificar, consultar y eliminar proveedores. */
@Controller
@RequestMapping("/proveedores")
public class ProveedorController {
    private final ProveedorService service;
    public ProveedorController(ProveedorService service) { this.service = service; }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("proveedores", service.listar());
        model.addAttribute("proveedor", new Proveedor());
        return "proveedores/lista";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Proveedor proveedor) {
        service.guardar(proveedor);
        return "redirect:/proveedores";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Integer id) {
        service.eliminar(id);
        return "redirect:/proveedores";
    }
}
