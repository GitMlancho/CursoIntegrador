package com.techfin.invsuite.controller;

import com.techfin.invsuite.service.ReporteService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/** RF-09: reportes de inventario y movimientos, exportables a PDF. */
@Controller
@RequestMapping("/reportes")
public class ReporteController {

    private final ReporteService reporteService;
    private final TemplateEngine templateEngine;

    public ReporteController(ReporteService reporteService, TemplateEngine templateEngine) {
        this.reporteService = reporteService;
        this.templateEngine = templateEngine;
    }

    @GetMapping
    public String reportes(Model model) {
        model.addAttribute("stock", reporteService.generarReporteStock());
        model.addAttribute("entradas", reporteService.generarReporteEntradas());
        model.addAttribute("salidas", reporteService.generarReporteSalidas());
        return "reportes/index";
    }

    @GetMapping("/stock/pdf")
    public ResponseEntity<byte[]> exportarStockPdf() {
        Context context = new Context();
        context.setVariable("stock", reporteService.generarReporteStock());
        String html = templateEngine.process("reportes/stock-pdf", context);
        byte[] pdf = reporteService.exportarPDF(html);

        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=reporte-stock.pdf");
        return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF).body(pdf);
    }
}
