package com.techfin.invsuite.repository;

import com.techfin.invsuite.model.Notificacion;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface NotificacionRepository extends JpaRepository<Notificacion, Integer> {
    List<Notificacion> findByLeidaFalseOrderByFechaDesc();
    List<Notificacion> findAllByOrderByFechaDesc();
    long countByLeidaFalse();
}
