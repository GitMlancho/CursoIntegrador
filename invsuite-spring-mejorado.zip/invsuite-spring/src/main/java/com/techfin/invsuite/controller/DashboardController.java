package com.techfin.invsuite.controller;

import com.techfin.invsuite.service.NotificacionService;
import com.techfin.invsuite.service.ProductoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {

    private final ProductoService productoService;
    private final NotificacionService notificacionService;

    public DashboardController(ProductoService productoService, NotificacionService notificacionService) {
        this.productoService = productoService;
        this.notificacionService = notificacionService;
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("totalProductos", productoService.listarTodos().size());
        model.addAttribute("stockBajo", productoService.listarConStockBajoMinimo());
        model.addAttribute("notificacionesNoLeidas", notificacionService.listarNoLeidas());
        model.addAttribute("totalNoLeidas", notificacionService.contarNoLeidas());
        return "dashboard";
    }
}
