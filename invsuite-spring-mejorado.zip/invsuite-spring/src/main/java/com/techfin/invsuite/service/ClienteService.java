package com.techfin.invsuite.service;

import com.techfin.invsuite.model.Cliente;
import com.techfin.invsuite.repository.ClienteRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ClienteService {
    private final ClienteRepository repo;
    public ClienteService(ClienteRepository repo) { this.repo = repo; }

    public List<Cliente> listar() { return repo.findAll(); }
    public Cliente guardar(Cliente c) { return repo.save(c); }
    public Cliente buscarPorId(Integer id) { return repo.findById(id).orElseThrow(); }
    public void eliminar(Integer id) { repo.deleteById(id); }
}
