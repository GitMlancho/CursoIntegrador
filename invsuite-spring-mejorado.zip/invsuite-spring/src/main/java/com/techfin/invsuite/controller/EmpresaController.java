package com.techfin.invsuite.controller;

import com.techfin.invsuite.model.Empresa;
import com.techfin.invsuite.service.EmpresaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/** RF-10: administrar los datos generales de la empresa utilizados en los reportes. */
@Controller
@RequestMapping("/empresa")
public class EmpresaController {

    private final EmpresaService service;
    public EmpresaController(EmpresaService service) { this.service = service; }

    @GetMapping
    public String ver(Model model) {
        model.addAttribute("empresa", service.obtener());
        return "empresa/form";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Empresa empresa) {
        service.actualizarDatos(empresa);
        return "redirect:/empresa";
    }
}
