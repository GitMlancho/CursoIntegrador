package com.techfin.invsuite.service;

import com.techfin.invsuite.model.Proveedor;
import com.techfin.invsuite.repository.ProveedorRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ProveedorService {
    private final ProveedorRepository repo;
    public ProveedorService(ProveedorRepository repo) { this.repo = repo; }

    public List<Proveedor> listar() { return repo.findAll(); }
    public Proveedor guardar(Proveedor p) { return repo.save(p); }
    public Proveedor buscarPorId(Integer id) { return repo.findById(id).orElseThrow(); }
    public void eliminar(Integer id) { repo.deleteById(id); }
}
