package com.techfin.invsuite.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

@Entity
@Table(name = "producto")
public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotBlank
    @Column(nullable = false, length = 150)
    private String nombre;

    @Column(name = "stock_actual", nullable = false)
    private int stockActual = 0;

    @Column(name = "stock_minimo", nullable = false)
    private int stockMinimo = 0;

    @Column(name = "precio_venta", nullable = false)
    private double precioVenta;

    @ManyToOne
    @JoinColumn(name = "id_categoria", nullable = false)
    private Categoria categoria;

    @ManyToOne
    @JoinColumn(name = "id_proveedor", nullable = false)
    private Proveedor proveedor;

    /** RF-08: incrementa el stock cuando ingresa una entrada. */
    public void aumentarStock(int cantidad) {
        this.stockActual += cantidad;
    }

    /** RF-07: valida disponibilidad y descuenta el stock en una salida. */
    public void disminuirStock(int cantidad) {
        if (cantidad > this.stockActual) {
            throw new IllegalStateException(
                "Stock insuficiente para el producto '" + nombre + "'. Disponible: " + stockActual);
        }
        this.stockActual -= cantidad;
    }

    /** RF-08: true si el stock llegó o cayó por debajo del mínimo configurado. */
    public boolean verificarStockMinimo() {
        return this.stockActual <= this.stockMinimo;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public int getStockActual() { return stockActual; }
    public void setStockActual(int stockActual) { this.stockActual = stockActual; }
    public int getStockMinimo() { return stockMinimo; }
    public void setStockMinimo(int stockMinimo) { this.stockMinimo = stockMinimo; }
    public double getPrecioVenta() { return precioVenta; }
    public void setPrecioVenta(double precioVenta) { this.precioVenta = precioVenta; }
    public Categoria getCategoria() { return categoria; }
    public void setCategoria(Categoria categoria) { this.categoria = categoria; }
    public Proveedor getProveedor() { return proveedor; }
    public void setProveedor(Proveedor proveedor) { this.proveedor = proveedor; }
}
