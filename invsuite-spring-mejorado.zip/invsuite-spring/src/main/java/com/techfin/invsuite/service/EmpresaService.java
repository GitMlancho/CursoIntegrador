package com.techfin.invsuite.service;

import com.techfin.invsuite.model.Empresa;
import com.techfin.invsuite.repository.EmpresaRepository;
import org.springframework.stereotype.Service;

/** RF-10: administrar los datos generales de la empresa utilizados en los reportes. */
@Service
public class EmpresaService {
    private final EmpresaRepository repo;
    public EmpresaService(EmpresaRepository repo) { this.repo = repo; }

    public Empresa obtener() {
        return repo.findAll().stream().findFirst().orElseGet(Empresa::new);
    }

    public Empresa actualizarDatos(Empresa empresa) {
        return repo.save(empresa);
    }
}
