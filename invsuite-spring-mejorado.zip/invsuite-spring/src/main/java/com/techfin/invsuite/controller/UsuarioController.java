package com.techfin.invsuite.controller;

import com.techfin.invsuite.model.Usuario;
import com.techfin.invsuite.repository.RolRepository;
import com.techfin.invsuite.service.UsuarioService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

/** RF-01 / RF-11: gestión de usuarios y roles (solo ADMIN). */
@Controller
@RequestMapping("/usuarios")
public class UsuarioController {
    private final UsuarioService service;
    private final RolRepository rolRepository;

    public UsuarioController(UsuarioService service, RolRepository rolRepository) {
        this.service = service;
        this.rolRepository = rolRepository;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("usuarios", service.listarTodos());
        model.addAttribute("usuario", new Usuario());
        model.addAttribute("roles", rolRepository.findAll());
        return "usuarios/lista";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Usuario usuario) {
        if (usuario.getId() == null) {
            service.registrar(usuario);
        } else {
            service.actualizar(usuario);
        }
        return "redirect:/usuarios";
    }
}
