package com.techfin.invsuite.service;

import com.techfin.invsuite.model.Entrada;
import com.techfin.invsuite.model.Producto;
import com.techfin.invsuite.model.Salida;
import com.techfin.invsuite.repository.EntradaRepository;
import com.techfin.invsuite.repository.ProductoRepository;
import com.techfin.invsuite.repository.SalidaRepository;
import com.openhtmltopdf.pdfboxout.PdfRendererBuilder;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.util.List;

/**
 * RF-09: genera reportes de inventario y movimientos, exportables a PDF.
 * <<service>> ReporteService: generarReporteStock(), generarReporteMovimientos(), exportarPDF().
 */
@Service
public class ReporteService {

    private final ProductoRepository productoRepository;
    private final EntradaRepository entradaRepository;
    private final SalidaRepository salidaRepository;

    public ReporteService(ProductoRepository productoRepository,
                           EntradaRepository entradaRepository,
                           SalidaRepository salidaRepository) {
        this.productoRepository = productoRepository;
        this.entradaRepository = entradaRepository;
        this.salidaRepository = salidaRepository;
    }

    public List<Producto> generarReporteStock() {
        return productoRepository.findAll();
    }

    public List<Entrada> generarReporteEntradas() {
        return entradaRepository.findAllByOrderByFechaDesc();
    }

    public List<Salida> generarReporteSalidas() {
        return salidaRepository.findAllByOrderByFechaDesc();
    }

    /** Exporta un HTML (renderizado por Thymeleaf) a PDF usando openhtmltopdf. */
    public byte[] exportarPDF(String htmlContent) {
        try (ByteArrayOutputStream os = new ByteArrayOutputStream()) {
            PdfRendererBuilder builder = new PdfRendererBuilder();
            builder.useFastMode();
            builder.withHtmlContent(htmlContent, null);
            builder.toStream(os);
            builder.run();
            return os.toByteArray();
        } catch (Exception e) {
            throw new RuntimeException("Error generando el PDF del reporte", e);
        }
    }
}
