package com.techfin.invsuite.config;

import com.techfin.invsuite.model.Empresa;
import com.techfin.invsuite.model.Rol;
import com.techfin.invsuite.model.Usuario;
import com.techfin.invsuite.repository.EmpresaRepository;
import com.techfin.invsuite.repository.RolRepository;
import com.techfin.invsuite.repository.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * Carga datos iniciales (roles, usuario administrador y datos de la empresa)
 * la primera vez que se levanta la aplicación. Evita depender de un hash
 * BCrypt pre-calculado: la contraseña se cifra en tiempo de ejecución con el
 * mismo PasswordEncoder que usa Spring Security (RNF-03).
 */
@Component
public class DataSeeder implements CommandLineRunner {

    private final RolRepository rolRepository;
    private final UsuarioRepository usuarioRepository;
    private final EmpresaRepository empresaRepository;
    private final PasswordEncoder passwordEncoder;

    public DataSeeder(RolRepository rolRepository, UsuarioRepository usuarioRepository,
                       EmpresaRepository empresaRepository, PasswordEncoder passwordEncoder) {
        this.rolRepository = rolRepository;
        this.usuarioRepository = usuarioRepository;
        this.empresaRepository = empresaRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        Rol admin = rolRepository.findByNombre("ADMIN").orElseGet(() -> rolRepository.save(new Rol("ADMIN")));
        rolRepository.findByNombre("INVENTARIO").orElseGet(() -> rolRepository.save(new Rol("INVENTARIO")));
        rolRepository.findByNombre("VENTAS").orElseGet(() -> rolRepository.save(new Rol("VENTAS")));
        rolRepository.findByNombre("GERENTE").orElseGet(() -> rolRepository.save(new Rol("GERENTE")));

        if (usuarioRepository.findByEmail("admin@techfin.pe").isEmpty()) {
            Usuario u = new Usuario();
            u.setNombre("Administrador TechFin");
            u.setEmail("admin@techfin.pe");
            u.setPassword(passwordEncoder.encode("admin123")); // cambiar en producción
            u.setRol(admin);
            u.setActivo(true);
            usuarioRepository.save(u);
            System.out.println(">> Usuario administrador creado: admin@techfin.pe / admin123");
        }

        if (empresaRepository.findAll().isEmpty()) {
            Empresa e = new Empresa();
            e.setRazonSocial("TechFin Perú S.A.C.");
            e.setRuc("20609999999");
            e.setLogo("");
            empresaRepository.save(e);
        }
    }
}
