package com.techfin.invsuite.repository;

import com.techfin.invsuite.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface ProductoRepository extends JpaRepository<Producto, Integer> {
    @Query("select p from Producto p where p.stockActual <= p.stockMinimo")
    List<Producto> findByStockActualLessThanEqualStockMinimo();
}
