package com.techfin.invsuite.repository;

import com.techfin.invsuite.model.Entrada;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface EntradaRepository extends JpaRepository<Entrada, Integer> {
    List<Entrada> findAllByOrderByFechaDesc();
}
