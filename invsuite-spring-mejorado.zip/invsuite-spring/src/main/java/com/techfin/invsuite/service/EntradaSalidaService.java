package com.techfin.invsuite.service;

import com.techfin.invsuite.model.Entrada;
import com.techfin.invsuite.model.Producto;
import com.techfin.invsuite.model.Salida;
import com.techfin.invsuite.repository.EntradaRepository;
import com.techfin.invsuite.repository.ProductoRepository;
import com.techfin.invsuite.repository.SalidaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

/**
 * RF-06 / RF-07: registra entradas y salidas de productos, actualiza el stock
 * automáticamente y dispara la notificación de stock mínimo (RF-08).
 */
@Service
public class EntradaSalidaService {

    private final EntradaRepository entradaRepository;
    private final SalidaRepository salidaRepository;
    private final ProductoRepository productoRepository;
    private final NotificacionService notificacionService;

    public EntradaSalidaService(EntradaRepository entradaRepository,
                                 SalidaRepository salidaRepository,
                                 ProductoRepository productoRepository,
                                 NotificacionService notificacionService) {
        this.entradaRepository = entradaRepository;
        this.salidaRepository = salidaRepository;
        this.productoRepository = productoRepository;
        this.notificacionService = notificacionService;
    }

    @Transactional
    public Entrada registrarEntrada(Entrada entrada) {
        Producto producto = productoRepository.findById(entrada.getProducto().getId())
                .orElseThrow(() -> new IllegalArgumentException("Producto no existe"));
        producto.aumentarStock(entrada.getCantidad());
        productoRepository.save(producto);
        entrada.setProducto(producto);
        Entrada guardada = entradaRepository.save(entrada);
        // Una entrada también puede "liberar" o mantener la alerta; se evalúa igual.
        notificacionService.generarPorStockMinimo(producto);
        return guardada;
    }

    @Transactional
    public Salida registrarSalida(Salida salida) {
        Producto producto = productoRepository.findById(salida.getProducto().getId())
                .orElseThrow(() -> new IllegalArgumentException("Producto no existe"));
        producto.disminuirStock(salida.getCantidad()); // valida disponibilidad (RF-07)
        productoRepository.save(producto);
        salida.setProducto(producto);
        Salida guardada = salidaRepository.save(salida);
        notificacionService.generarPorStockMinimo(producto); // RF-08
        return guardada;
    }

    public List<Entrada> listarEntradas() {
        return entradaRepository.findAllByOrderByFechaDesc();
    }

    public List<Salida> listarSalidas() {
        return salidaRepository.findAllByOrderByFechaDesc();
    }
}
