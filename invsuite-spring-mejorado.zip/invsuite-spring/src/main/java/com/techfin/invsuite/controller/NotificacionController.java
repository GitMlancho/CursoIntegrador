package com.techfin.invsuite.controller;

import com.techfin.invsuite.service.NotificacionService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/** RF-08: consulta y marcado de notificaciones automáticas de stock mínimo. */
@Controller
public class NotificacionController {
    private final NotificacionService service;
    public NotificacionController(NotificacionService service) { this.service = service; }

    @GetMapping("/notificaciones")
    public String listar(Model model) {
        model.addAttribute("notificaciones", service.listarTodas());
        return "notificaciones/lista";
    }

    @GetMapping("/notificaciones/leer/{id}")
    public String marcarLeida(@PathVariable Integer id) {
        service.marcarLeida(id);
        return "redirect:/notificaciones";
    }
}
