package com.techfin.invsuite.controller;

import com.techfin.invsuite.model.Categoria;
import com.techfin.invsuite.service.CategoriaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

/** RF-02: registrar, modificar, consultar y eliminar categorías de productos. */
@Controller
@RequestMapping("/categorias")
public class CategoriaController {
    private final CategoriaService service;
    public CategoriaController(CategoriaService service) { this.service = service; }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("categorias", service.listar());
        model.addAttribute("categoria", new Categoria());
        return "categorias/lista";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Categoria categoria) {
        service.guardar(categoria);
        return "redirect:/categorias";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Integer id) {
        service.eliminar(id);
        return "redirect:/categorias";
    }
}
