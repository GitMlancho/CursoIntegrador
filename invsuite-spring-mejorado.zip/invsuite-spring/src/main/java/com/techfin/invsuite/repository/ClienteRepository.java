package com.techfin.invsuite.repository;

import com.techfin.invsuite.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClienteRepository extends JpaRepository<Cliente, Integer> {
}
