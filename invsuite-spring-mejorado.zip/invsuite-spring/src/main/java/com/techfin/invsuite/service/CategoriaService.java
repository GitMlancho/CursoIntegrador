package com.techfin.invsuite.service;

import com.techfin.invsuite.model.Categoria;
import com.techfin.invsuite.repository.CategoriaRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CategoriaService {
    private final CategoriaRepository repo;
    public CategoriaService(CategoriaRepository repo) { this.repo = repo; }

    public List<Categoria> listar() { return repo.findAll(); }
    public Categoria guardar(Categoria c) { return repo.save(c); }
    public Categoria buscarPorId(Integer id) { return repo.findById(id).orElseThrow(); }
    public void eliminar(Integer id) { repo.deleteById(id); }
}
