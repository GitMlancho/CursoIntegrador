package com.techfin.invsuite.service;

import com.techfin.invsuite.model.Producto;
import com.techfin.invsuite.repository.ProductoRepository;
import org.springframework.stereotype.Service;
import java.util.List;

/** RF-05: registrar, modificar, consultar y eliminar productos. */
@Service
public class ProductoService {

    private final ProductoRepository productoRepository;

    public ProductoService(ProductoRepository productoRepository) {
        this.productoRepository = productoRepository;
    }

    public List<Producto> listarTodos() {
        return productoRepository.findAll();
    }

    public Producto buscarPorId(Integer id) {
        return productoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Producto no encontrado: " + id));
    }

    public Producto guardar(Producto producto) {
        return productoRepository.save(producto);
    }

    public void eliminar(Integer id) {
        productoRepository.deleteById(id);
    }

    public List<Producto> listarConStockBajoMinimo() {
        return productoRepository.findByStockActualLessThanEqualStockMinimo();
    }
}
