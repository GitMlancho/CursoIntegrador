package com.techfin.invsuite.service;

import com.techfin.invsuite.model.Notificacion;
import com.techfin.invsuite.model.Producto;
import com.techfin.invsuite.repository.NotificacionRepository;
import org.springframework.stereotype.Service;
import java.util.List;

/** RF-08: genera notificaciones automáticas cuando el stock llega al mínimo. */
@Service
public class NotificacionService {

    private final NotificacionRepository notificacionRepository;

    public NotificacionService(NotificacionRepository notificacionRepository) {
        this.notificacionRepository = notificacionRepository;
    }

    public void generarPorStockMinimo(Producto producto) {
        if (producto.verificarStockMinimo()) {
            Notificacion n = new Notificacion();
            n.setTipo("STOCK_MINIMO");
            n.setMensaje("El producto '" + producto.getNombre() + "' alcanzó el stock mínimo ("
                    + producto.getStockActual() + "/" + producto.getStockMinimo() + ").");
            n.setProducto(producto);
            notificacionRepository.save(n);
        }
    }

    public List<Notificacion> listarNoLeidas() {
        return notificacionRepository.findByLeidaFalseOrderByFechaDesc();
    }

    public List<Notificacion> listarTodas() {
        return notificacionRepository.findAllByOrderByFechaDesc();
    }

    public long contarNoLeidas() {
        return notificacionRepository.countByLeidaFalse();
    }

    public void marcarLeida(Integer id) {
        notificacionRepository.findById(id).ifPresent(n -> {
            n.marcarLeida();
            notificacionRepository.save(n);
        });
    }
}
