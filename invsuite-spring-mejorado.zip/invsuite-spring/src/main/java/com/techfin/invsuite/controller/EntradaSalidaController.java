package com.techfin.invsuite.controller;

import com.techfin.invsuite.model.Entrada;
import com.techfin.invsuite.model.Salida;
import com.techfin.invsuite.repository.UsuarioRepository;
import com.techfin.invsuite.service.ClienteService;
import com.techfin.invsuite.service.EntradaSalidaService;
import com.techfin.invsuite.service.ProductoService;
import com.techfin.invsuite.service.ProveedorService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

/** RF-06 y RF-07: registrar entradas y salidas, actualizando el stock automáticamente. */
@Controller
public class EntradaSalidaController {

    private final EntradaSalidaService movimientoService;
    private final ProductoService productoService;
    private final ProveedorService proveedorService;
    private final ClienteService clienteService;
    private final UsuarioRepository usuarioRepository;

    public EntradaSalidaController(EntradaSalidaService movimientoService, ProductoService productoService,
                                    ProveedorService proveedorService, ClienteService clienteService,
                                    UsuarioRepository usuarioRepository) {
        this.movimientoService = movimientoService;
        this.productoService = productoService;
        this.proveedorService = proveedorService;
        this.clienteService = clienteService;
        this.usuarioRepository = usuarioRepository;
    }

    @GetMapping("/entradas")
    public String entradas(Model model) {
        model.addAttribute("entradas", movimientoService.listarEntradas());
        model.addAttribute("entrada", new Entrada());
        model.addAttribute("productos", productoService.listarTodos());
        model.addAttribute("proveedores", proveedorService.listar());
        return "movimientos/entradas";
    }

    @PostMapping("/entradas/guardar")
    public String guardarEntrada(@ModelAttribute Entrada entrada, Authentication auth) {
        entrada.setUsuario(usuarioRepository.findByEmail(auth.getName()).orElseThrow());
        movimientoService.registrarEntrada(entrada);
        return "redirect:/entradas";
    }

    @GetMapping("/salidas")
    public String salidas(Model model) {
        model.addAttribute("salidas", movimientoService.listarSalidas());
        model.addAttribute("salida", new Salida());
        model.addAttribute("productos", productoService.listarTodos());
        model.addAttribute("clientes", clienteService.listar());
        return "movimientos/salidas";
    }

    @PostMapping("/salidas/guardar")
    public String guardarSalida(@ModelAttribute Salida salida, Authentication auth, Model model) {
        salida.setUsuario(usuarioRepository.findByEmail(auth.getName()).orElseThrow());
        try {
            movimientoService.registrarSalida(salida);
        } catch (IllegalStateException ex) {
            model.addAttribute("error", ex.getMessage());
            model.addAttribute("salidas", movimientoService.listarSalidas());
            model.addAttribute("salida", new Salida());
            model.addAttribute("productos", productoService.listarTodos());
            model.addAttribute("clientes", clienteService.listar());
            return "movimientos/salidas";
        }
        return "redirect:/salidas";
    }
}
