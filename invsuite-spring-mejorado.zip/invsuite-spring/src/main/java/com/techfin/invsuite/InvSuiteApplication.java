package com.techfin.invsuite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Sistema de Inventario y Notificaciones - TechFin Peru S.A.C.
 * Alternativa 2: InvSuite Spring (Spring Boot + Thymeleaf + Spring Data JPA + Spring Security)
 */
@SpringBootApplication
public class InvSuiteApplication {
    public static void main(String[] args) {
        SpringApplication.run(InvSuiteApplication.class, args);
    }
}
