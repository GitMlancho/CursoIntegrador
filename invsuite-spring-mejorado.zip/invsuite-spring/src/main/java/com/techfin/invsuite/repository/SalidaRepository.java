package com.techfin.invsuite.repository;

import com.techfin.invsuite.model.Salida;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SalidaRepository extends JpaRepository<Salida, Integer> {
    List<Salida> findAllByOrderByFechaDesc();
}
