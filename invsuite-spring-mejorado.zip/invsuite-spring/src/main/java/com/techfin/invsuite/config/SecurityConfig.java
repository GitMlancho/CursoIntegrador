package com.techfin.invsuite.config;

import com.techfin.invsuite.service.UsuarioService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

/**
 * RF-01: login por correo y contraseña validando el rol del usuario.
 * RF-11: restringe el acceso a los módulos según el nivel de usuario (rol).
 * RNF-03: contraseñas cifradas (BCrypt) y control de acceso por roles.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider(UsuarioService usuarioService,
                                                              PasswordEncoder passwordEncoder) {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(usuarioService);
        provider.setPasswordEncoder(passwordEncoder);
        return provider;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/css/**", "/js/**", "/login").permitAll()
                .requestMatchers("/usuarios/**", "/empresa/**").hasRole("ADMIN")
                .requestMatchers("/categorias/**", "/proveedores/**").hasAnyRole("ADMIN", "INVENTARIO")
                .requestMatchers("/productos/**", "/entradas/**").hasAnyRole("ADMIN", "INVENTARIO")
                .requestMatchers("/salidas/**", "/clientes/**").hasAnyRole("ADMIN", "VENTAS", "INVENTARIO")
                .requestMatchers("/reportes/**").hasAnyRole("ADMIN", "GERENTE")
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/login")
                .defaultSuccessUrl("/dashboard", true)
                .permitAll()
            )
            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/login?logout")
                .permitAll()
            );
        return http.build();
    }
}
